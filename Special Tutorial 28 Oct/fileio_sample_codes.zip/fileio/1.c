//directly from command line
#include<stdio.h>
int main()
{
	int a[5];
	int i,sum=0;
	for(i=0;i<5;i++)
		//scanf("%d",&a[i]);
	for(i=0;i<5;i++)
		sum=sum+a[i];
	printf("sum : %d\n",sum);
	return 0;
}
