// example using fgets and fputs
#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *f,*f1;
	char c[50];
	char s1[50]="input1.txt";
	f=fopen(s1,"r");
	f1=fopen("out2.txt","w");
	if(f1==NULL || f==NULL)
	{
		printf("error accessing file\n");
		exit(1);
	}

	//printf("%d\n",EOF);
	while(fgets(c,50,f)!=NULL)
	{
		fputs(c,f1);
		//printf("%c",c);
	}
	fclose(f);

	fclose(f1);
	return 0;
}
