// file io usiing structures
#include<stdio.h>
#include<stdlib.h>
struct s{
	char car[30];
	int price;
	char code;
};
int compare(const void *a, const void *b)
{
	return ((struct s *)a)->price-((struct s *)b)->price;
}
int main(int argc, char *argv[])
{
	struct s v[5];
	FILE *f,*f1;
	f=fopen("input2.txt","r");
	f1=fopen("out2.txt","w");
	if(f==NULL || f1==NULL)
	{
		printf("file access denied\n");
		exit(1);
	}
	printf("%p		%p\n",f,f1);
	int i=0;
	fprintf(f1,"data received from file:\n");
	while(fscanf(f,"%s%d%c",v[i].car,&v[i].price,&v[i].code)!=EOF)
	{
		fprintf(f1,"%s   %d   %c\n",v[i].car,v[i].price,v[i].code);
		i++;
	}
	fprintf(f1,"\n\n");
	qsort(v,5,sizeof(struct s),compare);
	fprintf(f1,"cars in increasing order of price:\n");
	for(i=0;i<5;i++)
		fprintf(f1,"%s   %d   %c\n",v[i].car,v[i].price,v[i].code);
	fclose(f);
	fclose(f1);
	return 0;
}
