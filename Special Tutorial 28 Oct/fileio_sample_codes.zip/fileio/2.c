// read from file and write to a file , value of EOF
#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *f;
	int c,sum=0;
	f=fopen("input.txt","r");
	if(f==NULL)
	{
		printf("error accessing file\n");
		exit(1);
	}
	printf("%d\n",EOF);
	while(fscanf(f,"%d",&c)!=EOF)
	{
		sum=sum+c;
		//printf("%c",c);
	}
	FILE *f1;

	f1=fopen("out1.txt","w");
	if(f1==NULL)
	{
		printf("error accessing file\n");
		exit(1);
	}
	fprintf(f1,"sum1: %d\n",sum);
	fclose(f);
	fclose(f1);
	return 0;
}
